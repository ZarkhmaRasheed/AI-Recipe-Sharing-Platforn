import React from 'react';
import './LoginMenu.css'
export default function LoginMenu() {
  return (
    <div className='LoginInstruction'>
    <h1>Please login first before using any feature</h1>
    </div>
  );
}